## load libraries ##
library(tidyverse)
library(neonUtilities)
library(restR)
library(magrittr)
library(readxl)
library(neonutils)
library(neondata)
library(neontask1b)

## Pull portal data for YELL vst and div ##
# get dpids
#div = "DP1.10058.001"
#vst = "DP1.10098.001"
#nst = "DP1.10045.001"

##
div_portal <- loadByProduct(dpID= "DP1.10058.001",
                     site = "YELL",
                     package = "basic",
                     check.size = FALSE, 
                     token = Sys.getenv('NEON_KEY'))

vst_portal <- loadByProduct(dpID= "DP1.10098.001",
                     site = "YELL",
                     package = "basic",
                     check.size = FALSE, 
                     token = Sys.getenv('NEON_KEY'))

# nst <- loadByProduct(dpID= "DP1.10045.001",
#                      site = "YELL",
#                      package = "basic",
#                      check.size = FALSE, 
#                      token = Sys.getenv('NEON_KEY'))

# unlist all data frames
list2env(div_portal,.GlobalEnv)
#list2env(nst,.GlobalEnv) #nst table not generated for YELL
list2env(vst_portal,.GlobalEnv)

#rm(nst) 
rm(div)
rm(vst)
#rm(categoricalCodes_10045)
rm(categoricalCodes_10058)
rm(categoricalCodes_10098)
rm(validation_10058)
rm(validation_10098)
rm(variables_10058)
rm(variables_10098)

## look at csp div and vst formatting
load(file = "neon-tos-sampling-design/code/neondata/data/vst.rda")
load(file = "neon-tos-sampling-design/code/neondata/data/div.rda")

## format and save so it looks the same as data delivered to csp ##
csp_divNames <- names(div)
csp_vstNames <- names(vst)

#my new plots
pList <- c("YELL_011", "YELL_016", "YELL_006", "YELL_013", "YELL_003")

## prep div df
div_10_sub <- select(div_1m2Data, csp_divNames, endDate)
div_100_sub <- select(div_10m2Data100m2Data, csp_divNames[1:4], endDate) #percentCover not preent in >1m sampling area data

div <- bind_rows(div_10_sub, div_100_sub)
div$year <- substr(div$endDate, 1, 4)

div_yell <- div%>%
  filter(plotID%in%pList & year=="2019" & !is.na(taxonID))


write.csv(div_yell, 'kjFiles/YELL_div_2019.csv', 
          row.names = FALSE)
rm(div)

##prep vst df
mapNames <- intersect(names(vst_mappingandtagging), csp_vstNames)
map_sub <- select(vst_mappingandtagging, mapNames, tagID=individualID, -subplotID)

vst_apparentindividual <- vst_apparentindividual%>%
  rename(tagID = individualID,
         maxCanopyDiameter = maxCrownDiameter,
         ninetyCanopyDiameter = ninetyCrownDiameter,
         stemStatus = plantStatus, 
         shrubShape = shape, 
         maxBaseCanopyDiameter = maxBaseCrownDiameter,
         ninetyBaseCanopyDiameter = ninetyBaseCrownDiameter)


aiNames <- intersect(names(vst_apparentindividual), csp_vstNames)

ai_sub <- select(vst_apparentindividual, aiNames, eventID)

vst_yell <- left_join(ai_sub, map_sub)%>%
  filter(plotID%in%pList & eventID=="vst_YELL_2019" & stemStatus!="No longer qualifies")

unique(vst$growthForm)
unique(vst_yell$growthForm)  #growth form coded in csp, full name on portal, recode
vst_yell$growthForm <- ifelse(vst_yell$growthForm=="small shrub", "sms",
                              ifelse(vst_yell$growthForm=="single bole tree", "sbt", 
                                     ifelse(vst_yell$growthForm=="sapling", "sap", vst_yell$growthForm)))


vst_yell$stemDiameter <- ifelse(vst_yell$growthForm=="sap", 
                                ifelse(is.na(vst_yell$stemDiameter), 
                                       vst_yell$basalStemDiameter,
                                       vst_yell$stemDiameter),
                                vst_yell$stemDiameter)
 
write.csv(vst_yell, 'kjFiles/YELL_vst_2019.csv', 
          row.names = FALSE)


### prep spatial data
load(file = "neon-tos-sampling-design/code/neondata/data/perPlot.rda")
load(file = "neon-tos-sampling-design/code/neondata/data/plotArea.rda")
load(file = "neon-tos-sampling-design/code/neondata/data/plotCoordinates.rda")

names(perPlot)
names(plotArea)
names(plotCoordinates)

#perPlot
intersect(names(perPlot), names(vst_perplotperyear))

plot_yell <- vst_perplotperyear%>%
  filter(plotID%in%pList & eventID=="vst_YELL_2019")%>%
  select(one_of(names(perPlot)))

plot_yell$nestedSubplotAreaShrubSapling <- as.integer(plot_yell$nestedSubplotAreaShrubSapling)
plot_yell$nestedSubplotAreaLiana <- ifelse(plot_yell$nestedSubplotAreaLiana=="noneSelected", 100, 
                                           plot_yell$nestedSubplotAreaLiana)

plot_out <- bind_rows(perPlot, plot_yell)
perPlot <- plot_out

save(perPlot, file = "neon-tos-sampling-design/code/neondata/data/perPlot.rda")


# plotArea
plotArea_out <- plotArea%>%
  add_row(siteID = "YELL", plotID = "YELL_003", plotSize= 400)%>%
  add_row(siteID = "YELL", plotID = "YELL_006", plotSize= 400)%>%
  add_row(siteID = "YELL", plotID = "YELL_011", plotSize= 400)%>%
  add_row(siteID = "YELL", plotID = "YELL_013", plotSize= 400)%>%
  add_row(siteID = "YELL", plotID = "YELL_016", plotSize= 400)

plotArea <- plotArea_out

save(plotArea, file = "neon-tos-sampling-design/code/neondata/data/plotArea.rda") 

## plotCoordinates
# all neon dat
daveFile <- read.csv('kjFiles/allSpatialInfo2018December26.csv')
# csp object
load(file = "neon-tos-sampling-design/code/neondata/data/plotCoordinates.rda")
names(plotCoordinates)

#anything missing?
setdiff(names(plotCoordinates), names(daveFile))
# referencePointPosition - not sure if this is used anywhere?

coord_out <- daveFile%>%
  filter(plotID%in%pList)%>%
  select(one_of(names(plotCoordinates)))%>%
  distinct(plotID, .keep_all = TRUE)

#add it to plotCoord
p_coord <- bind_rows(plotCoordinates, coord_out)
plotCoordinates <- p_coord

save(plotCoordinates, file = "neon-tos-sampling-design/code/neondata/data/plotCoordinates.rda") 


#########################################################
rm(list = ls())

# Get vst and div site level summaries
vst_yell <- read.csv('kjFiles/YELL_vst_2019.csv', 
                     stringsAsFactors=FALSE)


div_yell <- read.csv('kjFiles/YELL_div_2019.csv', 
                     stringsAsFactors=FALSE)


## run abundance code ##
## add missing fields that are called in nested functions 
## these are both shrubgroup fields, YELL does not have shrubgroups
vst_yell$canopyArea <- NA
vst_yell$liveCanopyArea <- NA
##vstAbundance doesn't work, YELL plots are not in csp plot lists ##
vstAbundance <- vstAbundanceBySite(vst_yell)
divAbundance <- divAbundanceBySite(div_yell)

